/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package attendencepro;

import dao.BiometricDataDao;
import dao.AttendenceDao;
import dao.StudentDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import model.Attendence;
import model.BiometricData;
import model.Student;
import Service.GetConnection;


public class TimeManager {

    public static String getTotalBreakTime(ArrayList<BiometricData> al) {
        String totalBreakTime = "00:00";
        for (int i = 1; i < al.size() - 1; i++) {
            String dif = getDifferenceBtwTimes(al.get(i).getTime(), al.get(i + 1).getTime());
            totalBreakTime = getAdditionBtwTimes(totalBreakTime, dif);
            i++;
        }
        return totalBreakTime;
    }

    public static String getTotalInTime(ArrayList<BiometricData> al) {
        String totalTime = getDifferenceBtwTimes(al.get(0).getTime(), al.get(al.size() - 1).getTime());
        String totalBreakTime = getTotalBreakTime(al);
        totalTime = getDifferenceBtwTimes(totalBreakTime, totalTime);
        return totalTime;
    }

    public static String getDifferenceBtwTimes(String time1, String time2) {
        String arr1[] = time1.split(":");
        String arr2[] = time2.split(":");

        int entryHour = Integer.parseInt(arr1[0]);
        int exitHour = Integer.parseInt(arr2[0]);

        int entryMin = Integer.parseInt(arr1[1]);
        int exitMin = Integer.parseInt(arr2[1]);

        if (exitMin < entryMin) {
            exitMin = exitMin + 60;
            exitHour--;
        }

        int totalMin = exitMin - entryMin;

        int totalHour = exitHour - entryHour;

        if (totalMin >= 60) {
            totalMin = totalMin - 60;
            totalHour++;
        }
        return totalHour + ":" + totalMin;
    }

    public static String getAdditionBtwTimes(String time1, String time2) {

        String arr1[] = time1.split(":");
        String arr2[] = time2.split(":");

        int entryHour = Integer.parseInt(arr1[0]);
        int exitHour = Integer.parseInt(arr2[0]);

        int entryMin = Integer.parseInt(arr1[1]);
        int exitMin = Integer.parseInt(arr2[1]);

        int totalMin = exitMin + entryMin;

        int totalHour = exitHour + entryHour;

        if (totalMin >= 60) {
            totalMin = totalMin - 60;
            totalHour++;
        }
        return totalHour + ":" + totalMin;
    }

    public static boolean checkHalfDay(String totalTime) {
        String marginTime = "7:15";

        String arr1[] = totalTime.split(":");
        String arr2[] = marginTime.split(":");

        int tbtHour = Integer.parseInt(arr1[0]);
        int mHour = Integer.parseInt(arr2[0]);

        int tbtMin = Integer.parseInt(arr1[1]);
        int mMin = Integer.parseInt(arr2[1]);

        if (tbtHour < mHour) {
            return false;
        } else if (tbtHour > mHour) {
            return true;
        } else if (tbtHour == mHour && tbtMin >= mMin) {
            return true;
        }

        return false;
    }

    public static ArrayList<Attendence> getAttendenceByDate(String date) {
        ArrayList<Attendence> attendenceMains = new ArrayList<Attendence>();

        ArrayList<Student> students = StudentDao.getAllStudentsData();

        for (Student st : students) {
            ArrayList<BiometricData> al =  BiometricDataDao.getBiometricDataByDateAndId(st.getStudentId(), date);
            
            int id = st.getStudentId();
            String inTime;
            String outTime;
            String duration;
            String totalBreakTime;
            String status;

            if (al.size() == 0) {
                status = "ABSENT";
                inTime = "--:--";
                outTime = "--:--";
                totalBreakTime = "--:--";
                duration = "--:--";
            } else if (!TimeManager.checkHalfDay(TimeManager.getTotalInTime(al))) {
                status = "HALF-DAY";
                inTime = al.get(0).getTime();
                outTime = al.get(al.size() - 1).getTime();
                totalBreakTime = TimeManager.getTotalBreakTime(al);
                duration = TimeManager.getTotalInTime(al);
            } else {
                status = "PRESENT";
                inTime = al.get(0).getTime();
                outTime = al.get(al.size() - 1).getTime();
                totalBreakTime = TimeManager.getTotalBreakTime(al);
                duration = TimeManager.getTotalInTime(al);
            }

            Attendence am = new Attendence(id, st.getStudentName(), date, inTime, outTime, duration, totalBreakTime, status);
            attendenceMains.add(am);
        }
        return attendenceMains;
    }

    public static Attendence getAttendenceByDateAndId(String i, String date) {

        ArrayList<BiometricData> al = BiometricDataDao.getBiometricDataByDateAndId(Integer.parseInt(i), date);
        int id =  Integer.parseInt(i) + 1;
        String inTime;
        String outTime;
        String duration;
        String totalBreakTime;
        String status;

        if (al.size() == 0) {
            status = "A";
            inTime = "--:--";
            outTime = "--:--";
            totalBreakTime = "--:--";
            duration = "--:--";
        } else if (!TimeManager.checkHalfDay(TimeManager.getTotalInTime(al))) {
            status = "H";
            inTime = al.get(0).getTime();
            outTime = al.get(al.size() - 1).getTime();
            totalBreakTime = TimeManager.getTotalBreakTime(al);
            duration = TimeManager.getTotalInTime(al);
        } else {
            status = "P";
            inTime = al.get(0).getTime();
            outTime = al.get(al.size() - 1).getTime();
            totalBreakTime = TimeManager.getTotalBreakTime(al);
            duration = TimeManager.getTotalInTime(al);
        }

        Attendence am = new Attendence(id, StudentDao.getStudentDataById(id).getStudentName(), date, inTime, outTime, duration, totalBreakTime, status);

        return am;
    }

    public static String[][] sortOutMatter(int year,int month) {
        Connection con = GetConnection.getConnection();     
        String arr[][] = new String[37][TimeManager.getTotalDaysInAMonth(year, month).length];
        int row=0;
        
        try {
            for (int i = 0; i < 37; i++) {
                String date;
                if (month < 10) {
                    date = "0" + month + "/" + year;
                } else {
                    date = "0" + month + "/" + year;
                }
                String q = "select student.id,student.name,attendence.status from (attendence inner join student on attendence.stdid=student.id) where stdid=" + (i + 1) + " AND date like '%/" + date + "';";
                PreparedStatement pstmt = con.prepareStatement(q);
                ResultSet set = pstmt.executeQuery();

                int col = 0;
                while (set.next()) {
                    if (col == 0) {
                        arr[row][col++] = "" + set.getInt("id");
                        arr[row][col++] = set.getString("name");
                        arr[row][col++] = set.getString("status").substring(0,1);
                    } else {
                        arr[row][col++] = set.getString("status").substring(0,1);
                    }
                }
                row++;

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return arr;
    }

    public static String[] countWeekendDays(int year, int month) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, 1);
        ArrayList<String> al = new ArrayList<String>();

        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        for (int day = 1; day <= daysInMonth; day++) {
            calendar.set(year, month - 1, day);
            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek != Calendar.SUNDAY) {
                al.add("" + calendar.get(Calendar.DATE));
            }
        }
        String a[] = Arrays.asList(al.toArray()).toArray(new String[al.toArray().length]);
        return a;
    }

    public static String[] makeTableColumn(int year, int month) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, 1);
        ArrayList<String> al = new ArrayList<String>();
        al.add("STD ID");
        al.add("Name");
        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        for (int day = 1; day <= daysInMonth; day++) {
            calendar.set(year, month - 1, day);
            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek != Calendar.SUNDAY) {
                al.add("" + calendar.get(Calendar.DATE));
            }
        }
        String a[] = Arrays.asList(al.toArray()).toArray(new String[al.toArray().length]);
        return a;
    }

    public static String[] getSundays(int year, int month) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, 1);
        ArrayList<String> al = new ArrayList<String>();
        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        for (int day = 1; day <= daysInMonth; day++) {
            calendar.set(year, month - 1, day);
            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek == Calendar.SUNDAY) {
                al.add("" + calendar.get(Calendar.DATE));
            }
        }
        String a[] = Arrays.asList(al.toArray()).toArray(new String[al.toArray().length]);
        return a;
    }
    
    public static String[] getTotalDaysInAMonth(int year, int month) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, 1);
        ArrayList<String> al = new ArrayList<String>();

        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        for (int day = 1; day <= daysInMonth; day++) {
            calendar.set(year, month - 1, day);
            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
                al.add("" + calendar.get(Calendar.DATE));
        }
        String a[] = Arrays.asList(al.toArray()).toArray(new String[al.toArray().length]);
        return a;
    }

}
