package attendencepro;

import dao.AttendenceDao;
import dao.StudentDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.*;
import Service.GetConnection;

public class AttendencePro {

    public static void main(String[] args) {
        String arr[] = TimeManager.countWeekendDays(2023, 2);

        for(int i=0;i<arr.length;i++){
          String date;
            if (Integer.parseInt(arr[i]) < 10) {
                date = "0" + arr[i] + "/02/2023";
            } else {
                date = arr[i] + "/02/2023";
            }
          ArrayList<Attendence> al = TimeManager.getAttendenceByDate(date);
          
          for(Attendence am : al)
              AttendenceDao.addAttendence(am);
        }


//        for (int i = 0; i < arr.length; i++) {
//            String date;
//            if (Integer.parseInt(arr[i]) < 10) {
//                date = "0" + arr[i] + "/02/2023";
//            } else {
//                date = arr[i] + "/02/2023";
//            }
//
//            System.out.println(i + 1 + " " + StudentDao.getStudentName(i+1) + " " + date);
//        }
        

       
    }
}
