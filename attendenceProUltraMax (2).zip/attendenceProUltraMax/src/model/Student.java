package model;

public class Student {

    private int studentId;
    private String studentName;
    private String studentDateOfBirth;
    private String studentGender;
    private String studentEmail;
    private String studentMobileNumber;
    private String studentLocalAddress;
    private String studentPermanentAddress;
    private String studentQualification;
    private String studentYearOfPassing;
    private String studentAadhaarCardNumber;
    private String studentBloodGroup;
    private int batchId;
    private boolean studentStatus;
    private String studentFatherName;
    private String studentMotherName;
    private String studentParentsMobileNumber;

    public Student(int studentId, String studentName, String studentDateOfBirth, String studentGender, String studentEmail, String studentMobileNumber, String studentLocalAddress, String studentPermanentAddress, String studentQualification, String studentYearOfPassing, String studentAadhaarCardNumber, String studentBloodGroup, int batchId, boolean studentStatus, String studentFatherName, String studentMotherName, String studentParentsMobileNumber) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentDateOfBirth = studentDateOfBirth;
        this.studentGender = studentGender;
        this.studentEmail = studentEmail;
        this.studentMobileNumber = studentMobileNumber;
        this.studentLocalAddress = studentLocalAddress;
        this.studentPermanentAddress = studentPermanentAddress;
        this.studentQualification = studentQualification;
        this.studentYearOfPassing = studentYearOfPassing;
        this.studentAadhaarCardNumber = studentAadhaarCardNumber;
        this.studentBloodGroup = studentBloodGroup;
        this.batchId = batchId;
        this.studentStatus = studentStatus;
        this.studentFatherName = studentFatherName;
        this.studentMotherName = studentMotherName;
        this.studentParentsMobileNumber = studentParentsMobileNumber;
    }

    public Student() {
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentDateOfBirth() {
        return studentDateOfBirth;
    }

    public void setStudentDateOfBirth(String studentDateOfBirth) {
        this.studentDateOfBirth = studentDateOfBirth;
    }

    public String getStudentGender() {
        return studentGender;
    }

    public void setStudentGender(String studentGender) {
        this.studentGender = studentGender;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getStudentMobileNumber() {
        return studentMobileNumber;
    }

    public void setStudentMobileNumber(String studentMobileNumber) {
        this.studentMobileNumber = studentMobileNumber;
    }

    public String getStudentLocalAddress() {
        return studentLocalAddress;
    }

    public void setStudentLocalAddress(String studentLocalAddress) {
        this.studentLocalAddress = studentLocalAddress;
    }

    public String getStudentPermanentAddress() {
        return studentPermanentAddress;
    }

    public void setStudentPermanentAddress(String studentPermanentAddress) {
        this.studentPermanentAddress = studentPermanentAddress;
    }

    public String getStudentQualification() {
        return studentQualification;
    }

    public void setStudentQualification(String studentQualification) {
        this.studentQualification = studentQualification;
    }

    public String getStudentYearOfPassing() {
        return studentYearOfPassing;
    }

    public void setStudentYearOfPassing(String studentYearOfPassing) {
        this.studentYearOfPassing = studentYearOfPassing;
    }

    public String getStudentAadhaarCardNumber() {
        return studentAadhaarCardNumber;
    }

    public void setStudentAadhaarCardNumber(String studentAadhaarCardNumber) {
        this.studentAadhaarCardNumber = studentAadhaarCardNumber;
    }

    public String getStudentBloodGroup() {
        return studentBloodGroup;
    }

    public void setStudentBloodGroup(String studentBloodGroup) {
        this.studentBloodGroup = studentBloodGroup;
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public boolean isStudentStatus() {
        return studentStatus;
    }

    public void setStudentStatus(boolean studentStatus) {
        this.studentStatus = studentStatus;
    }

    public String getStudentFatherName() {
        return studentFatherName;
    }

    public void setStudentFatherName(String studentFatherName) {
        this.studentFatherName = studentFatherName;
    }

    public String getStudentMotherName() {
        return studentMotherName;
    }

    public void setStudentMotherName(String studentMotherName) {
        this.studentMotherName = studentMotherName;
    }

    public String getStudentParentsMobileNumber() {
        return studentParentsMobileNumber;
    }

    public void setStudentParentsMobileNumber(String studentParentsMobileNumber) {
        this.studentParentsMobileNumber = studentParentsMobileNumber;
    }

    
}
