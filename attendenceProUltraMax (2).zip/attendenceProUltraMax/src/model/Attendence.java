package model;
public class Attendence {
    private int studentId;
    private String studentName;
    private String currentDate;
    private String studentCheckInTime;
    private String studentCheckOutTime;
    private String totalTimeSpendInClass;
    private String totalBreakTime;
    private String studentCurrentDayStatus;

    public Attendence(int studentId, String studentName, String currentDate, String studentCheckInTime, String studentCheckOutTime, String totalTimeSpendInClass, String totalBreakTime, String studentCurrentDayStatus) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.currentDate = currentDate;
        this.studentCheckInTime = studentCheckInTime;
        this.studentCheckOutTime = studentCheckOutTime;
        this.totalTimeSpendInClass = totalTimeSpendInClass;
        this.totalBreakTime = totalBreakTime;
        this.studentCurrentDayStatus = studentCurrentDayStatus;
    }

    public Attendence() {
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    public String getStudentCheckInTime() {
        return studentCheckInTime;
    }

    public void setStudentCheckInTime(String studentCheckInTime) {
        this.studentCheckInTime = studentCheckInTime;
    }

    public String getStudentCheckOutTime() {
        return studentCheckOutTime;
    }

    public void setStudentCheckOutTime(String studentCheckOutTime) {
        this.studentCheckOutTime = studentCheckOutTime;
    }

    public String getTotalTimeSpendInClass() {
        return totalTimeSpendInClass;
    }

    public void setTotalTimeSpendInClass(String totalTimeSpendInClass) {
        this.totalTimeSpendInClass = totalTimeSpendInClass;
    }

    public String getTotalBreakTime() {
        return totalBreakTime;
    }

    public void setTotalBreakTime(String totalBreakTime) {
        this.totalBreakTime = totalBreakTime;
    }

    public String getStudentCurrentDayStatus() {
        return studentCurrentDayStatus;
    }

    public void setStudentCurrentDayStatus(String studentCurrentDayStatus) {
        this.studentCurrentDayStatus = studentCurrentDayStatus;
    }

    
    
}
