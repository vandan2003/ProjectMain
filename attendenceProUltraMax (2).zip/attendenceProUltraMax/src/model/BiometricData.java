package model;

public class BiometricData {
    private int biometricId;
    private int studentId;
    private String date;
    private String time;

    public BiometricData(int biometricId, int studentId, String date, String time) {
        this.biometricId = biometricId;
        this.studentId = studentId;
        this.date = date;
        this.time = time;
    }
    
     public BiometricData(int biometricId, String date, String time) {
        this.biometricId = biometricId;
        this.date = date;
        this.time = time;
    }

    public BiometricData() {
    }

    public int getBiometricId() {
        return biometricId;
    }

    public void setBiometricId(int biometricId) {
        this.biometricId = biometricId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    
    
}
