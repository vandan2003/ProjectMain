package model;
public class Batch {
    private int batchId;
    private String batchName;
    private String batchStartingDate;
    private String totalStudents;

    public Batch(int batchId, String batchName, String batchStartingDate, String totalStudents) {
        this.batchId = batchId;
        this.batchName = batchName;
        this.batchStartingDate = batchStartingDate;
        this.totalStudents = totalStudents;
    }

    public Batch() {
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public String getBatchName() {
        return batchName;
    }

    public void setBatchName(String batchName) {
        this.batchName = batchName;
    }

    public String getBatchStartingDate() {
        return batchStartingDate;
    }

    public void setBatchStartingDate(String batchStartingDate) {
        this.batchStartingDate = batchStartingDate;
    }

    public String getTotalStudents() {
        return totalStudents;
    }

    public void setTotalStudents(String totalStudents) {
        this.totalStudents = totalStudents;
    }

    
    
}
