package dao;

public class BatchDao {
    
}
