package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import Service.GetConnection;
import model.*;
import dao.*; 
import java.sql.ResultSet;

public class StudentDao {
    
    public static boolean addStudentData(Student student) {

        boolean status = false;

        Connection con = null;

        try {

            con = GetConnection.getConnection();

            String sql = " insert into Student (stdId,studentName,studentDateOfBirth,studentGender,studentEmail,studentMobileNumber,studentLocalAddress,studentPermanentAddress,studentQualification,studentYearOfPassing,studentAadhaarCardNumber,studentBloodGroup,batchId,studentStatus,studentFatherName,studentMotherName,studentParentsMobileNumber) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, student.getStudentId());
            ps.setString(2, student.getStudentName());
            ps.setString(3, student.getStudentDateOfBirth());
            ps.setString(4, student.getStudentGender());
            ps.setString(5, student.getStudentEmail());
            ps.setString(6, student.getStudentMobileNumber());
            ps.setString(7, student.getStudentLocalAddress());
            ps.setString(8, student.getStudentPermanentAddress());
            ps.setString(9, student.getStudentQualification());
            ps.setString(10, student.getStudentYearOfPassing());
            ps.setString(11, student.getStudentAadhaarCardNumber());
            ps.setString(12, student.getStudentBloodGroup());
            ps.setInt(13, student.getBatchId());
            ps.setBoolean(14, student.isStudentStatus());
            ps.setString(15, student.getStudentFatherName());
            ps.setString(16, student.getStudentMotherName());
            ps.setString(17, student.getStudentParentsMobileNumber());

            if (ps.executeUpdate() != 0) {
                status = true;
            }

        } catch (Exception e) {
            System.out.println("" + e);
        } finally {

            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return status;

    }
    
    public static ArrayList<Student> getAllStudentsData() {

        Connection con = null;

        ArrayList<Student> students = new ArrayList<>();

        try {

            con = GetConnection.getConnection();

            String sql = " select * from Student ";

            PreparedStatement pstmt = con.prepareStatement(sql);

            ResultSet set = pstmt.executeQuery();

            while (set.next()) {

                int stdId = set.getInt("stdId");
                String studentName = set.getString("studentName");
                String studentDateOfBirth = set.getString("studentDateOfBirth");
                String studentGender = set.getString("studentGender");
                String studentEmail = set.getString("studentEmail");
                String studentMobileNumber = set.getString("studentMobileNumber");
                String studentLocalAddress = set.getString("studentLocalAddress");
                String studentPermanentAddress = set.getString("studentPermanentAddress");
                String studentQualification = set.getString("studentQualification");
                String studentYearOfPassing = set.getString("studentYearOfPassing");
                String studentAadhaarCardNumber = set.getString("studentAadhaarCardNumber");
                String studentBloodGroup = set.getString("studentBloodGroup");
                int batchId = set.getInt("batchId");
                boolean studentStatus = set.getBoolean("studentStatus");
                String studentFatherName = set.getString("studentFatherName");
                String studentMotherName = set.getString("studentMotherName");
                String studentParentsMobileNumber = set.getString("studentParentsMobileNumber");
                Student student = new Student(stdId, studentName, studentDateOfBirth, studentGender, studentEmail, studentMobileNumber, studentLocalAddress, studentPermanentAddress, studentQualification, studentYearOfPassing, studentAadhaarCardNumber, studentBloodGroup, batchId, studentStatus, studentFatherName, studentMotherName, studentParentsMobileNumber);
                students.add(student);

            }

        } catch (Exception e) {
            System.out.println("" + e);
        } finally {

            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return students;

    }
    
    public static Student getStudentDataById(int id) {

        Connection con = null;

        Student std = null;

        try {

            con = GetConnection.getConnection();
            
            String sql = " select * from student where id ="+id+";";
           
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet set = pstmt.executeQuery();
            
            

            while (set.next()) {

                int stdId = set.getInt("Id");
                String studentName = set.getString("Name");
                String studentDateOfBirth = set.getString("DateOfBirth");
                String studentGender = set.getString("Gender");
                String studentEmail = set.getString("Email");
                String studentMobileNumber = set.getString("MobileNumber");
                String studentLocalAddress = set.getString("LocalAddress");
                String studentPermanentAddress = set.getString("PermanentAddress");
                String studentQualification = set.getString("Qualification");
                String studentYearOfPassing = set.getString("YearOfPassing");
                String studentAadhaarCardNumber = set.getString("AdharNo");
                String studentBloodGroup = set.getString("BloodGroup");
                int batchId = set.getInt("batchId");
                boolean studentStatus = set.getBoolean("Status");
                String studentFatherName = set.getString("FatherName");
                String studentMotherName = set.getString("MotherName");
                String studentParentsMobileNumber = set.getString("ParentMobileNo");
                
                std = new Student(stdId, studentName, studentDateOfBirth, studentGender, studentEmail, studentMobileNumber, studentLocalAddress, studentPermanentAddress, studentQualification, studentYearOfPassing, studentAadhaarCardNumber, studentBloodGroup, batchId, studentStatus, studentFatherName, studentMotherName, studentParentsMobileNumber);

            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return std;

    }
    
    public static ArrayList<Student> getStudentsDataByBatch(String batch) {

        Connection con = null;

        ArrayList<Student> students = new ArrayList<>();

        try {

            con = GetConnection.getConnection();

            String sql = " select * from Student where batchId ='" + batch + "'";

            PreparedStatement pstmt = con.prepareStatement(sql);

            ResultSet set = pstmt.executeQuery();

            while (set.next()) {

                int stdId = set.getInt("stdId");
                String studentName = set.getString("studentName");
                String studentDateOfBirth = set.getString("studentDateOfBirth");
                String studentGender = set.getString("studentGender");
                String studentEmail = set.getString("studentEmail");
                String studentMobileNumber = set.getString("studentMobileNumber");
                String studentLocalAddress = set.getString("studentLocalAddress");
                String studentPermanentAddress = set.getString("studentPermanentAddress");
                String studentQualification = set.getString("studentQualification");
                String studentYearOfPassing = set.getString("studentYearOfPassing");
                String studentAadhaarCardNumber = set.getString("studentAadhaarCardNumber");
                String studentBloodGroup = set.getString("studentBloodGroup");
                int batchId = set.getInt("batchId");
                boolean studentStatus = set.getBoolean("studentStatus");
                String studentFatherName = set.getString("studentFatherName");
                String studentMotherName = set.getString("studentMotherName");
                String studentParentsMobileNumber = set.getString("studentParentsMobileNumber");
                Student student = new Student(stdId, studentName, studentDateOfBirth, studentGender, studentEmail, studentMobileNumber, studentLocalAddress, studentPermanentAddress, studentQualification, studentYearOfPassing, studentAadhaarCardNumber, studentBloodGroup, batchId, studentStatus, studentFatherName, studentMotherName, studentParentsMobileNumber);
                students.add(student);

            }

        } catch (Exception e) {
            System.out.println("" + e);
        } finally {

            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return students;

    }
    
    public static ArrayList<Student> getStudentsDataByDate(String date) {

        Connection con = null;

        ArrayList<Student> students = new ArrayList<>();

        try {

            con = GetConnection.getConnection();

            String sql = " select * from Student where date ='" + date + "'";

            PreparedStatement pstmt = con.prepareStatement(sql);

            ResultSet set = pstmt.executeQuery();

            while (set.next()) {

                int stdId = set.getInt("stdId");
                String studentName = set.getString("studentName");
                String studentDateOfBirth = set.getString("studentDateOfBirth");
                String studentGender = set.getString("studentGender");
                String studentEmail = set.getString("studentEmail");
                String studentMobileNumber = set.getString("studentMobileNumber");
                String studentLocalAddress = set.getString("studentLocalAddress");
                String studentPermanentAddress = set.getString("studentPermanentAddress");
                String studentQualification = set.getString("studentQualification");
                String studentYearOfPassing = set.getString("studentYearOfPassing");
                String studentAadhaarCardNumber = set.getString("studentAadhaarCardNumber");
                String studentBloodGroup = set.getString("studentBloodGroup");
                int batchId = set.getInt("batchId");
                boolean studentStatus = set.getBoolean("studentStatus");
                String studentFatherName = set.getString("studentFatherName");
                String studentMotherName = set.getString("studentMotherName");
                String studentParentsMobileNumber = set.getString("studentParentsMobileNumber");
                Student student = new Student(stdId, studentName, studentDateOfBirth, studentGender, studentEmail, studentMobileNumber, studentLocalAddress, studentPermanentAddress, studentQualification, studentYearOfPassing, studentAadhaarCardNumber, studentBloodGroup, batchId, studentStatus, studentFatherName, studentMotherName, studentParentsMobileNumber);
                students.add(student);

            }

        } catch (Exception e) {
            System.out.println("" + e);
        } finally {

            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return students;

    }
    
}
