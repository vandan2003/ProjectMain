package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import Service.GetConnection;
import model.*;

public class AttendenceDao {
    
    public static boolean addAttendence(Attendence a) {
        boolean status = false;
        Connection con = null;
        try {
            con = GetConnection.getConnection();
            String sql = " INSERT INTO Attendence(studentId,studentName,currentDate,studentCheckInTime,studentCheckOutTime,totalTimeSpendInClass,totalBreakTime,studentCurrentDayStatus) values (?,?,?,?,?,?,?,?);";
            PreparedStatement ps = con.prepareStatement(sql);
              ps.setInt(1,a.getStudentId());
            ps.setString(2, a.getStudentName());
            ps.setString(3, a.getCurrentDate());
            ps.setString(4, a.getStudentCheckInTime());
            ps.setString(5, a.getStudentCheckOutTime());
            ps.setString(6, a.getTotalTimeSpendInClass());
            ps.setString(7, a.getTotalBreakTime());
            ps.setString(8, a.getStudentCurrentDayStatus());
          
            if (ps.executeUpdate() != 0) {
                status = true;
            }

        } catch (Exception e) {
            System.out.println("" + e);
        } finally {
            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return status;
    }
    
    
}
