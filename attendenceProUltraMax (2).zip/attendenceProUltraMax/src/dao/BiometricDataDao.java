package dao;

import Service.GetConnection;
import model.BiometricData;
import java.util.ArrayList;
import java.sql.*;
import model.Attendence;

public class BiometricDataDao {

    public static ArrayList<BiometricData> getBiometricData() {

        ArrayList<BiometricData> al = new ArrayList<BiometricData>();

        Connection con = null;

        try {

            con = GetConnection.getConnection();

            String sql = " select * from BiometricData ";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int biometricId = rs.getInt("biometricId");
                int studentId = rs.getInt("stdId");
                String date = rs.getString("date");
                String time = rs.getString("time");
                BiometricData a = new BiometricData(biometricId, studentId, date, time);
                al.add(a);

            }

        } catch (Exception e) {
            System.out.println("e" + e);
        } finally {

            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return al;
    }

    public static ArrayList<BiometricData> getBiometricDataById(int id) {

        ArrayList<BiometricData> al = new ArrayList<BiometricData>();

        Connection con = null;

        try {

            con = GetConnection.getConnection();

            String sql = " select * from BiometricData where stdId = " + id + " ";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int biometricId = rs.getInt("biometricId");
                int studentId = rs.getInt("stdId");
                String date = rs.getString("date");
                String time = rs.getString("time");
                BiometricData a = new BiometricData(biometricId, id, date, time);
                al.add(a);

            }

        } catch (Exception e) {
            System.out.println("e" + e);
        } finally {

            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return al;
    }

    public static ArrayList<BiometricData> getBiometricDataByDate(String d) {

        ArrayList<BiometricData> al = new ArrayList<BiometricData>();

        Connection con = null;

        try {

            con = GetConnection.getConnection();

            String sql = " select * from BiometricData where date = '" + d + "' ";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int biometricId = rs.getInt("biometricId");
                int studentId = rs.getInt("stdId");
                String date = rs.getString("date");
                String time = rs.getString("time");
                BiometricData a = new BiometricData(biometricId, studentId, date, time);
                al.add(a);

            }

        } catch (Exception e) {
            System.out.println("e" + e);
        } finally {

            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return al;
    }

    public static ArrayList<BiometricData> getBiometricDataByDateAndId(int id, String d) {

        ArrayList<BiometricData> al = new ArrayList<BiometricData>();

        Connection con = null;

        try {

            con = GetConnection.getConnection();

            String sql = " select * from BiometricData where stdId = " + id + " AND date = '" + d + "' ";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int biometricId = rs.getInt("biometricId");
                int studentId = rs.getInt("stdId");
                String date = rs.getString("date");
                String time = rs.getString("time");
                BiometricData a = new BiometricData(biometricId, studentId, date, time);
                al.add(a);

            }

        } catch (Exception e) {
            System.out.println("e" + e);
        } finally {

            try {
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return al;
    }

}
