package dao;

public class AdminDao {
    
}
