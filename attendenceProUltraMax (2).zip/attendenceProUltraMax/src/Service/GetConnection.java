package Service;

import java.sql.Connection;
import java.sql.DriverManager;

public class GetConnection {

    private static Connection con = null;

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/AttendenceSystem", "root", "vijay222003");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

}
