
package frameJava;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JOptionPane;

public class MainMenu extends javax.swing.JFrame {

   
    public MainMenu() {
        initComponents();
        sizemy();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width / 2 - getWidth() / 2, size.height / 2 - getHeight() / 2);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MainPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        SideBar = new javax.swing.JPanel();
        viewAttendence = new javax.swing.JLabel();
        UpdateAtten = new javax.swing.JLabel();
        TakeAtten = new javax.swing.JLabel();
        viewDetails = new javax.swing.JLabel();
        addStudent = new javax.swing.JLabel();
        updateDetails = new javax.swing.JLabel();
        removeStudent = new javax.swing.JLabel();
        crossIcon = new javax.swing.JLabel();
        SideBarBGimg = new javax.swing.JLabel();
        HembugerIcon = new javax.swing.JLabel();
        BGImage = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        MainPanel.setMinimumSize(new java.awt.Dimension(1000, 625));
        MainPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-close-window-48.png"))); // NOI18N
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        MainPanel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1510, 10, -1, 40));

        SideBar.setBackground(new java.awt.Color(255, 255, 255));
        SideBar.setForeground(new java.awt.Color(255, 255, 255));
        SideBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        viewAttendence.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        viewAttendence.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewAttendenceMouseClicked(evt);
            }
        });
        SideBar.add(viewAttendence, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 200, 190, 20));

        UpdateAtten.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SideBar.add(UpdateAtten, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, 200, 20));

        TakeAtten.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SideBar.add(TakeAtten, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, 170, 20));

        viewDetails.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SideBar.add(viewDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 430, 130, 20));

        addStudent.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SideBar.add(addStudent, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 470, 130, 20));

        updateDetails.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SideBar.add(updateDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 520, 160, 20));

        removeStudent.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SideBar.add(removeStudent, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 570, 180, 20));

        crossIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        crossIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                crossIconMouseClicked(evt);
            }
        });
        SideBar.add(crossIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 10, 50, 30));

        SideBarBGimg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Side Bar-1.png"))); // NOI18N
        SideBarBGimg.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                SideBarBGimgMouseMoved(evt);
            }
        });
        SideBarBGimg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SideBarBGimgMouseClicked(evt);
            }
        });
        SideBar.add(SideBarBGimg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 430, 810));

        MainPanel.add(SideBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 430, 812));

        HembugerIcon.setFont(new java.awt.Font("Segoe UI", 0, 60)); // NOI18N
        HembugerIcon.setForeground(new java.awt.Color(255, 255, 255));
        HembugerIcon.setText("=");
        HembugerIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        HembugerIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HembugerIconMouseClicked(evt);
            }
        });
        MainPanel.add(HembugerIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 60, 50));

        BGImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/MainImg.jpg"))); // NOI18N
        MainPanel.add(BGImage, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1564, 812));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1564, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(MainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 812, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(MainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    int x = 430;
    private void crossIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_crossIconMouseClicked
      if(x == 430){
        SideBar.setSize(430,812);
        Thread th = new Thread(){
        @Override
        public void run(){
        try{
          for(int i=430;i>=0;i--){
            Thread.sleep(1);
            SideBar.setSize(i,812);
          }
        }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
        }
        };th.start();
        x=0;
      }
    }//GEN-LAST:event_crossIconMouseClicked
    
    public void sizemy(){
           // of the screen in pixels
        Dimension size
            = Toolkit.getDefaultToolkit().getScreenSize();
        
        // width will store the width of the screen
        int width = (int)size.getWidth();
        
        // height will store the height of the screen
        int height = (int)size.getHeight();
        
        System.out.println("Current Screen resolution : "
                           + "width : " + width
                           + " height : " + height);
    }
    
    
    private void HembugerIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HembugerIconMouseClicked
        if(x == 0){
            SideBar.show();
            SideBar.setSize(x,812);
            Thread th = new Thread(){
                @Override
                public void run(){
                    try{
                        for(int i=0;i<=x;i++){
                            Thread.sleep(1);
                            SideBar.setSize(i,812);
                        }
                    }catch(Exception e){
                        JOptionPane.showMessageDialog(null,e);
                    }
                }
            };th.start();
            x=430;
        }
    }//GEN-LAST:event_HembugerIconMouseClicked

    private void SideBarBGimgMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SideBarBGimgMouseMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_SideBarBGimgMouseMoved

    private void SideBarBGimgMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SideBarBGimgMouseClicked
        // TODO add your handling code here:
      
       
        
    }//GEN-LAST:event_SideBarBGimgMouseClicked

    private void viewAttendenceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewAttendenceMouseClicked
        // TODO add your handling code here:
        new ViewAttendence().setVisible(true);
    }//GEN-LAST:event_viewAttendenceMouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jLabel1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BGImage;
    private javax.swing.JLabel HembugerIcon;
    private javax.swing.JPanel MainPanel;
    private javax.swing.JPanel SideBar;
    private javax.swing.JLabel SideBarBGimg;
    private javax.swing.JLabel TakeAtten;
    private javax.swing.JLabel UpdateAtten;
    private javax.swing.JLabel addStudent;
    private javax.swing.JLabel crossIcon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel removeStudent;
    private javax.swing.JLabel updateDetails;
    private javax.swing.JLabel viewAttendence;
    private javax.swing.JLabel viewDetails;
    // End of variables declaration//GEN-END:variables
}
